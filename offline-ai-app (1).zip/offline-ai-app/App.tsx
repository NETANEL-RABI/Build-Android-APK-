import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { TouchableOpacity, Text, StyleSheet } from 'react-native';
import ChatScreen from './src/screens/ChatScreen';
import ModelsScreen from './src/screens/ModelsScreen';
import { AppProvider } from './src/context/AppContext';

export type RootStackParamList = {
  Chat: undefined;
  Models: undefined;
};

const Stack = createNativeStackNavigator<RootStackParamList>();

const navTheme = {
  dark: true,
  colors: {
    primary: '#4f8cff',
    background: '#0f1115',
    card: '#15171c',
    text: '#ffffff',
    border: '#2a2e37',
    notification: '#4f8cff',
  },
} as const;

export default function App() {
  return (
    <SafeAreaProvider>
      <AppProvider>
        <NavigationContainer theme={navTheme as any}>
          <Stack.Navigator>
            <Stack.Screen
              name="Chat"
              component={ChatScreen}
              options={({ navigation }) => ({
                title: "צ'אט AI אופליין",
                headerRight: () => (
                  <TouchableOpacity
                    style={styles.headerButton}
                    onPress={() => navigation.navigate('Models')}>
                    <Text style={styles.headerButtonText}>מודלים</Text>
                  </TouchableOpacity>
                ),
              })}
            />
            <Stack.Screen
              name="Models"
              component={ModelsScreen}
              options={{ title: 'ניהול מודלים' }}
            />
          </Stack.Navigator>
        </NavigationContainer>
      </AppProvider>
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  headerButton: { paddingHorizontal: 12, paddingVertical: 6 },
  headerButtonText: { color: '#4f8cff', fontWeight: '600' },
});
