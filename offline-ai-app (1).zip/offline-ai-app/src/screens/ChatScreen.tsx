import React, { useRef, useState } from 'react';
import {
  View,
  Text,
  FlatList,
  TextInput,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
  StyleSheet,
  ActivityIndicator,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { LlamaService } from '../services/LlamaService';
import { useAppContext } from '../context/AppContext';
import { ChatMessage } from '../types';

let idCounter = 0;
const nextId = () => `${Date.now()}-${idCounter++}`;

export default function ChatScreen() {
  const navigation = useNavigation<any>();
  const { activeModel, isModelLoading, loadProgress } = useAppContext();

  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const listRef = useRef<FlatList<ChatMessage>>(null);

  const scrollToEnd = () => {
    requestAnimationFrame(() => listRef.current?.scrollToEnd({ animated: true }));
  };

  const handleSend = async () => {
    const text = input.trim();
    if (!text || isGenerating) {
      return;
    }

    if (!LlamaService.isLoaded()) {
      navigation.navigate('Models');
      return;
    }

    const userMessage: ChatMessage = {
      id: nextId(),
      role: 'user',
      content: text,
      timestamp: Date.now(),
    };

    const assistantMessage: ChatMessage = {
      id: nextId(),
      role: 'assistant',
      content: '',
      timestamp: Date.now(),
    };

    const history = [...messages, userMessage];
    setMessages([...history, assistantMessage]);
    setInput('');
    setIsGenerating(true);
    scrollToEnd();

    try {
      let acc = '';
      await LlamaService.generate(history, token => {
        acc += token;
        setMessages(prev =>
          prev.map(m => (m.id === assistantMessage.id ? { ...m, content: acc } : m)),
        );
      });
    } catch (err: any) {
      setMessages(prev =>
        prev.map(m =>
          m.id === assistantMessage.id
            ? { ...m, content: `שגיאה: ${err?.message ?? 'משהו השתבש'}` }
            : m,
        ),
      );
    } finally {
      setIsGenerating(false);
      scrollToEnd();
    }
  };

  const renderItem = ({ item }: { item: ChatMessage }) => (
    <View
      style={[
        styles.bubble,
        item.role === 'user' ? styles.bubbleUser : styles.bubbleAssistant,
      ]}>
      <Text style={styles.bubbleText}>{item.content || '...'}</Text>
    </View>
  );

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      {!activeModel && (
        <TouchableOpacity
          style={styles.banner}
          onPress={() => navigation.navigate('Models')}>
          <Text style={styles.bannerText}>
            לא נטען מודל. הקש כאן כדי לבחור ולטעון מודל (פעם אחת, דורש אינטרנט להורדה).
          </Text>
        </TouchableOpacity>
      )}

      {activeModel && (
        <View style={styles.subHeader}>
          <Text style={styles.subHeaderText}>מודל פעיל: {activeModel.name}</Text>
        </View>
      )}

      {isModelLoading && (
        <View style={styles.loadingRow}>
          <ActivityIndicator />
          <Text style={styles.loadingText}>
            טוען מודל למכשיר... {loadProgress.toFixed(0)}%
          </Text>
        </View>
      )}

      <FlatList
        ref={listRef}
        data={messages}
        keyExtractor={item => item.id}
        renderItem={renderItem}
        contentContainerStyle={styles.listContent}
        onContentSizeChange={scrollToEnd}
      />

      <View style={styles.inputRow}>
        <TextInput
          style={styles.input}
          value={input}
          onChangeText={setInput}
          placeholder="כתוב הודעה..."
          placeholderTextColor="#6b7280"
          multiline
          textAlign="right"
        />
        <TouchableOpacity
          style={[styles.sendButton, isGenerating && styles.sendButtonDisabled]}
          onPress={handleSend}
          disabled={isGenerating}>
          {isGenerating ? (
            <ActivityIndicator color="#fff" size="small" />
          ) : (
            <Text style={styles.sendButtonText}>שלח</Text>
          )}
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0f1115' },
  banner: {
    backgroundColor: '#3a2e1a',
    padding: 12,
    margin: 12,
    borderRadius: 10,
  },
  bannerText: { color: '#ffcf8b', textAlign: 'right', fontSize: 13 },
  subHeader: {
    paddingHorizontal: 16,
    paddingTop: 8,
  },
  subHeaderText: { color: '#6b7280', fontSize: 12, textAlign: 'right' },
  loadingRow: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: 8,
    padding: 12,
  },
  loadingText: { color: '#a0a4ab', fontSize: 13 },
  listContent: { padding: 12, gap: 10 },
  bubble: {
    maxWidth: '85%',
    borderRadius: 14,
    paddingVertical: 10,
    paddingHorizontal: 14,
  },
  bubbleUser: {
    alignSelf: 'flex-end',
    backgroundColor: '#4f8cff',
  },
  bubbleAssistant: {
    alignSelf: 'flex-start',
    backgroundColor: '#1a1d24',
    borderWidth: 1,
    borderColor: '#2a2e37',
  },
  bubbleText: { color: '#fff', fontSize: 15, textAlign: 'right' },
  inputRow: {
    flexDirection: 'row-reverse',
    alignItems: 'flex-end',
    padding: 10,
    gap: 8,
    borderTopWidth: 1,
    borderTopColor: '#2a2e37',
  },
  input: {
    flex: 1,
    backgroundColor: '#1a1d24',
    borderRadius: 12,
    color: '#fff',
    paddingHorizontal: 14,
    paddingVertical: 10,
    maxHeight: 120,
    fontSize: 15,
  },
  sendButton: {
    backgroundColor: '#4f8cff',
    borderRadius: 12,
    paddingHorizontal: 18,
    paddingVertical: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  sendButtonDisabled: { backgroundColor: '#37404f' },
  sendButtonText: { color: '#fff', fontWeight: '700' },
});
