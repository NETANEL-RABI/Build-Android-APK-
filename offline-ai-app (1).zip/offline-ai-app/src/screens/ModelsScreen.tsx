import React, { useEffect, useState, useCallback } from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
  StyleSheet,
} from 'react-native';
import { AVAILABLE_MODELS, ModelManager } from '../services/ModelManager';
import { LlamaService } from '../services/LlamaService';
import { useAppContext } from '../context/AppContext';
import { ModelInfo } from '../types';

type DownloadState = Record<string, { downloaded: boolean; progress: number; busy: boolean }>;

export default function ModelsScreen() {
  const { activeModel, setActiveModel, isModelLoading, setIsModelLoading, setLoadProgress } =
    useAppContext();

  const [state, setState] = useState<DownloadState>({});

  const refreshStatuses = useCallback(async () => {
    const next: DownloadState = {};
    for (const model of AVAILABLE_MODELS) {
      const downloaded = await ModelManager.isDownloaded(model);
      next[model.id] = { downloaded, progress: 0, busy: false };
    }
    setState(next);
  }, []);

  useEffect(() => {
    refreshStatuses();
  }, [refreshStatuses]);

  const handleDownload = async (model: ModelInfo) => {
    setState(prev => ({ ...prev, [model.id]: { ...prev[model.id], busy: true, progress: 0 } }));
    try {
      await ModelManager.downloadModel(model, percent => {
        setState(prev => ({
          ...prev,
          [model.id]: { ...prev[model.id], progress: percent, busy: true },
        }));
      });
      setState(prev => ({
        ...prev,
        [model.id]: { downloaded: true, progress: 100, busy: false },
      }));
    } catch (err: any) {
      Alert.alert('שגיאה בהורדה', err?.message ?? 'נסה שוב כשיש חיבור לאינטרנט.');
      setState(prev => ({
        ...prev,
        [model.id]: { ...prev[model.id], busy: false, progress: 0 },
      }));
    }
  };

  const handleSelect = async (model: ModelInfo) => {
    setIsModelLoading(true);
    setLoadProgress(0);
    try {
      const path = ModelManager.getLocalPath(model);
      await LlamaService.loadModel(path, model.contextSize, percent => {
        setLoadProgress(percent);
      });
      setActiveModel(model);
    } catch (err: any) {
      Alert.alert('שגיאה בטעינת המודל', err?.message ?? 'נסה שוב.');
    } finally {
      setIsModelLoading(false);
    }
  };

  const handleDelete = async (model: ModelInfo) => {
    if (activeModel?.id === model.id) {
      await LlamaService.unload();
      setActiveModel(null);
    }
    await ModelManager.deleteModel(model);
    setState(prev => ({ ...prev, [model.id]: { downloaded: false, progress: 0, busy: false } }));
  };

  const renderItem = ({ item }: { item: ModelInfo }) => {
    const itemState = state[item.id] ?? { downloaded: false, progress: 0, busy: false };
    const isActive = activeModel?.id === item.id;

    return (
      <View style={[styles.card, isActive && styles.cardActive]}>
        <View style={styles.cardHeader}>
          <Text style={styles.modelName}>{item.name}</Text>
          {isActive && <Text style={styles.activeBadge}>פעיל</Text>}
        </View>
        <Text style={styles.modelDesc}>{item.description}</Text>
        <Text style={styles.modelSize}>גודל הורדה: {item.sizeLabel}</Text>

        {itemState.busy && (
          <View style={styles.progressRow}>
            <ActivityIndicator size="small" />
            <Text style={styles.progressText}>
              מוריד... {itemState.progress.toFixed(0)}%
            </Text>
          </View>
        )}

        <View style={styles.actionsRow}>
          {!itemState.downloaded && !itemState.busy && (
            <TouchableOpacity style={styles.button} onPress={() => handleDownload(item)}>
              <Text style={styles.buttonText}>הורד מודל</Text>
            </TouchableOpacity>
          )}

          {itemState.downloaded && !isActive && (
            <TouchableOpacity
              style={[styles.button, styles.buttonPrimary]}
              disabled={isModelLoading}
              onPress={() => handleSelect(item)}>
              <Text style={styles.buttonText}>
                {isModelLoading ? 'טוען...' : 'טען מודל זה'}
              </Text>
            </TouchableOpacity>
          )}

          {itemState.downloaded && (
            <TouchableOpacity
              style={[styles.button, styles.buttonDanger]}
              onPress={() => handleDelete(item)}>
              <Text style={styles.buttonText}>מחק</Text>
            </TouchableOpacity>
          )}
        </View>
      </View>
    );
  };

  return (
    <View style={styles.container}>
      <Text style={styles.header}>
        בחר מודל להורדה (פעם אחת, דורש אינטרנט) ולטעינה. לאחר הטעינה, השיחה תרוץ
        לחלוטין במכשיר - בלי אינטרנט.
      </Text>
      <FlatList
        data={AVAILABLE_MODELS}
        keyExtractor={item => item.id}
        renderItem={renderItem}
        contentContainerStyle={styles.listContent}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0f1115' },
  header: {
    color: '#a0a4ab',
    fontSize: 13,
    padding: 16,
    textAlign: 'right',
  },
  listContent: { padding: 12, gap: 12 },
  card: {
    backgroundColor: '#1a1d24',
    borderRadius: 12,
    padding: 14,
    borderWidth: 1,
    borderColor: '#2a2e37',
  },
  cardActive: {
    borderColor: '#4f8cff',
  },
  cardHeader: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  modelName: { color: '#fff', fontSize: 16, fontWeight: '600', textAlign: 'right' },
  activeBadge: {
    color: '#4f8cff',
    fontSize: 12,
    fontWeight: '700',
  },
  modelDesc: { color: '#a0a4ab', fontSize: 13, marginTop: 4, textAlign: 'right' },
  modelSize: { color: '#6b7280', fontSize: 12, marginTop: 4, textAlign: 'right' },
  progressRow: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: 8,
    marginTop: 10,
  },
  progressText: { color: '#a0a4ab', fontSize: 12 },
  actionsRow: {
    flexDirection: 'row-reverse',
    gap: 8,
    marginTop: 12,
  },
  button: {
    paddingVertical: 8,
    paddingHorizontal: 14,
    borderRadius: 8,
    backgroundColor: '#2a2e37',
  },
  buttonPrimary: { backgroundColor: '#4f8cff' },
  buttonDanger: { backgroundColor: '#7a2e2e' },
  buttonText: { color: '#fff', fontSize: 13, fontWeight: '600' },
});
