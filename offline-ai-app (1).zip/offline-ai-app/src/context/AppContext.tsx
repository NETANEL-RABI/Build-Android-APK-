import React, { createContext, useContext, useState, ReactNode } from 'react';
import { ModelInfo } from '../types';

interface AppContextType {
  activeModel: ModelInfo | null;
  setActiveModel: (model: ModelInfo | null) => void;
  isModelLoading: boolean;
  setIsModelLoading: (loading: boolean) => void;
  loadProgress: number;
  setLoadProgress: (percent: number) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  const [activeModel, setActiveModel] = useState<ModelInfo | null>(null);
  const [isModelLoading, setIsModelLoading] = useState(false);
  const [loadProgress, setLoadProgress] = useState(0);

  return (
    <AppContext.Provider
      value={{
        activeModel,
        setActiveModel,
        isModelLoading,
        setIsModelLoading,
        loadProgress,
        setLoadProgress,
      }}>
      {children}
    </AppContext.Provider>
  );
}

export function useAppContext(): AppContextType {
  const ctx = useContext(AppContext);
  if (!ctx) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return ctx;
}
