export type MessageRole = 'user' | 'assistant' | 'system';

export interface ChatMessage {
  id: string;
  role: MessageRole;
  content: string;
  timestamp: number;
}

export interface ModelInfo {
  id: string;
  name: string;
  description: string;
  sizeLabel: string;
  /** Direct download URL to a GGUF file (e.g. on Hugging Face) */
  url: string;
  /** Filename used to store the model locally */
  filename: string;
  /** Recommended context window size */
  contextSize: number;
}
