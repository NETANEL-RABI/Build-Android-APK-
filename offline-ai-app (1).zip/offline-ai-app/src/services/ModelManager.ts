import RNFS from 'react-native-fs';
import { ModelInfo } from '../types';

/**
 * Catalog of small models that work well fully offline on a phone.
 * Sizes are approximate (quantized GGUF, q4_k_m).
 *
 * You can add more models here - just point to a direct .gguf
 * download URL (Hugging Face "resolve/main/..." links work well).
 */
export const AVAILABLE_MODELS: ModelInfo[] = [
  {
    id: 'qwen2.5-0.5b',
    name: 'Qwen2.5 0.5B Instruct',
    description: 'הקטן והקליל ביותר. מתאים למשימות פשוטות יומיומיות ולמכשירים חלשים.',
    sizeLabel: '~0.4GB',
    url:
      'https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct-GGUF/resolve/main/qwen2.5-0.5b-instruct-q4_k_m.gguf',
    filename: 'qwen2.5-0.5b-instruct-q4_k_m.gguf',
    contextSize: 2048,
  },
  {
    id: 'qwen2.5-1.5b',
    name: 'Qwen2.5 1.5B Instruct',
    description: 'איזון טוב בין גודל לחוכמה. מומלץ כברירת מחדל.',
    sizeLabel: '~1GB',
    url:
      'https://huggingface.co/Qwen/Qwen2.5-1.5B-Instruct-GGUF/resolve/main/qwen2.5-1.5b-instruct-q4_k_m.gguf',
    filename: 'qwen2.5-1.5b-instruct-q4_k_m.gguf',
    contextSize: 4096,
  },
  {
    id: 'phi-3-mini',
    name: 'Phi-3 Mini Instruct',
    description: 'חכם יותר אך גדול וכבד יותר. מתאים למכשירים חזקים עם 6GB+ RAM.',
    sizeLabel: '~2.3GB',
    url:
      'https://huggingface.co/microsoft/Phi-3-mini-4k-instruct-gguf/resolve/main/Phi-3-mini-4k-instruct-q4.gguf',
    filename: 'phi-3-mini-4k-instruct-q4.gguf',
    contextSize: 4096,
  },
];

const MODELS_DIR = `${RNFS.DocumentDirectoryPath}/models`;

class ModelManagerClass {
  async ensureModelsDir(): Promise<void> {
    const exists = await RNFS.exists(MODELS_DIR);
    if (!exists) {
      await RNFS.mkdir(MODELS_DIR);
    }
  }

  getLocalPath(model: ModelInfo): string {
    return `${MODELS_DIR}/${model.filename}`;
  }

  async isDownloaded(model: ModelInfo): Promise<boolean> {
    return RNFS.exists(this.getLocalPath(model));
  }

  /**
   * Downloads a model file. Requires an internet connection.
   * Call onProgress periodically with a 0-100 percent value.
   */
  async downloadModel(
    model: ModelInfo,
    onProgress?: (percent: number) => void,
  ): Promise<string> {
    await this.ensureModelsDir();
    const destPath = this.getLocalPath(model);
    const tmpPath = `${destPath}.part`;

    const { promise } = RNFS.downloadFile({
      fromUrl: model.url,
      toFile: tmpPath,
      progressDivider: 2,
      progress: res => {
        if (onProgress && res.contentLength > 0) {
          onProgress((res.bytesWritten / res.contentLength) * 100);
        }
      },
    });

    const result = await promise;

    if (result.statusCode && result.statusCode >= 400) {
      await RNFS.unlink(tmpPath).catch(() => {});
      throw new Error(`הורדה נכשלה עם קוד ${result.statusCode}`);
    }

    // Rename only after a successful full download
    await RNFS.moveFile(tmpPath, destPath);
    return destPath;
  }

  async deleteModel(model: ModelInfo): Promise<void> {
    const path = this.getLocalPath(model);
    if (await RNFS.exists(path)) {
      await RNFS.unlink(path);
    }
  }

  /** Returns free disk space in bytes, useful before downloading large models */
  async getFreeDiskSpace(): Promise<number> {
    const info = await RNFS.getFSInfo();
    return info.freeSpace;
  }
}

export const ModelManager = new ModelManagerClass();
