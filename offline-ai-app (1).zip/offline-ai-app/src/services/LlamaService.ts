import { initLlama, releaseAllLlama, LlamaContext } from 'llama.rn';
import { ChatMessage } from '../types';

/**
 * Thin wrapper around llama.rn that handles loading a local GGUF model
 * and running chat completions, fully offline.
 */
class LlamaServiceClass {
  private context: LlamaContext | null = null;
  private currentModelPath: string | null = null;

  /**
   * Loads (or reloads) a model from a local file path.
   * Safe to call again with the same path - it will be a no-op.
   */
  async loadModel(
    modelPath: string,
    contextSize: number,
    onProgress?: (percent: number) => void,
  ): Promise<void> {
    if (this.context && this.currentModelPath === modelPath) {
      return;
    }

    await this.unload();

    this.context = await initLlama(
      {
        model: modelPath,
        use_mlock: true,
        n_ctx: contextSize,
        // Keep at 0 for guaranteed CPU-only execution (most compatible).
        // Increase if you've confirmed GPU offload works on target devices.
        n_gpu_layers: 0,
      },
      progress => {
        onProgress?.(progress);
      },
    );

    this.currentModelPath = modelPath;
  }

  isLoaded(): boolean {
    return this.context !== null;
  }

  getCurrentModelPath(): string | null {
    return this.currentModelPath;
  }

  /**
   * Runs a chat completion against the loaded model.
   * onToken is called for each generated token (for streaming UI updates).
   */
  async generate(
    history: ChatMessage[],
    onToken?: (token: string) => void,
  ): Promise<string> {
    if (!this.context) {
      throw new Error('המודל לא נטען. עבור למסך "ניהול מודלים" וטען מודל.');
    }

    const messages = history.map(m => ({ role: m.role, content: m.content }));

    const result = await this.context.completion(
      {
        messages,
        n_predict: 512,
        temperature: 0.7,
        top_p: 0.9,
        stop: ['</s>', '<|im_end|>', '<|end|>'],
      },
      data => {
        if (data?.token) {
          onToken?.(data.token);
        }
      },
    );

    return result.text.trim();
  }

  async unload(): Promise<void> {
    if (this.context) {
      await this.context.release();
      this.context = null;
      this.currentModelPath = null;
    }
  }

  async unloadAll(): Promise<void> {
    await releaseAllLlama();
    this.context = null;
    this.currentModelPath = null;
  }
}

export const LlamaService = new LlamaServiceClass();
